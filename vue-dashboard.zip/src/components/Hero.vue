<script type="module">
</script>
<template>
    <section>
        <div class="row mx-5">
            <div class="col-5">
                <h6 class="l1">Lorem ipsum</h6>
                <h6 class="l2">dolor sit amet</h6>
                <h6 class="l3">Lorem Ipsum Dolor Sit Amet, Consectetur</h6>
                <div class="row mt-5">
                    <div class="col-6">
                        <button type="button" class="b1">Explore API</button>
                    </div>
                    <div class="col-6">
                        <button type="button" class="b2">Create API</button>
                    </div>
                </div>
            </div>
            <div class="col-7 d-flex justify-content-center hero-right">
                <img src="../assets/2905211.svg" alt="" class="hero-img">
            </div>
        </div>
    </section>
</template>
<style>
.b1,
.b2 {
    top: 417px;
    left: 328px;
    width: 179px;
    height: 44px;
    border: 1px solid #27DEBF;
    border-radius: 26px;
    opacity: 1;
    border-color: #27DEBF;
    color: black;

}

.b1 {
    background-color: #27DEBF;
}

.hero-img {
    top: 122px;
    left: 928px;
    width: 438px;
    height: 405px;

}

/* .hero-left {
    top: 137px;
    width: 389px;
    height: 466px;
} */
/* .hero-right {
    top: -169.9136962890625px;
    left: 477px;
    width: 1112px;
    height: 1041px;
    transform: matrix(-0.85, 0.53, -0.53, -0.85, 0, 0);
    background: #FFE7CC 0% 0% no-repeat padding-box;
    opacity: 0.5;
} */
/* .l {
    top: 188px;
    left: 132px;
    width: 551px;
    height: 149px;
    text-align: left;
    letter-spacing: 0px;
    color: #000000;
    opacity: 1;
} */
.l1 {
    width: 295px;
    height: 73px;
    text-align: left;
    font: normal normal normal 60px/70px Calibri;
    letter-spacing: -3px;
    color: #000000;
}

.l2 {
    top: 70px;
    left: 0px;
    width: 365px;
    height: 73px;
    text-align: left;
    font: normal normal bold 60px/70px Calibri;
    letter-spacing: 0px;
    color: #000000;
}

.l3 {
    top: 337px;
    left: 132px;
    width: 433px;
    height: 33px;
    text-align: left;
    font: normal normal normal 25px/40px Calibri;
    letter-spacing: 0px;
    color: #455A64;
    opacity: 1;
}
</style>