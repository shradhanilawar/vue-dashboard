<template>
    <section>
        <div class="row d-flex justify-content-between">
            <div class="col-2 c">
                <div class="circle c1">
                    <h6> 50%</h6>
                </div>
            </div>
            <div class="col-2 c">
                <div class="circle c1">
                    <h6> 75%</h6>
                </div>
            </div>
            <div class="col-2 c">
                <div class="circle c1">
                    <h6> 20%</h6>
                </div>
            </div>
            <div class="col-2 c">
                <div class="circle c1">
                    <h6> 50%</h6>
                </div>
            </div>
        </div>
    </section>
</template>

<style>
.c {
    /* Layout Properties */
    top: 629px;
    left: 287px;
    width: 134px;
    height: 134px;
    /* UI Properties */
    background: rgba(255, 255, 255, 1) 0% 0% no-repeat padding-box;
    box-shadow: 0px 15px 20px rgba(21, 29, 65, 0.06);
    opacity: 1;
}

.circle {
    top: 629px;
    left: 287px;
    width: 134px;
    height: 134px;
    /* UI Properties */
    background: rgba(255, 255, 255, 1) 0% 0% no-repeat padding-box;
    border: 2px solid rgba(15, 191, 97, 0.2);
    opacity: 1;
}

h6 {
    /* Layout Properties */
    top: 665px;
    left: 540px;
    width: 62px;
    height: 44px;
    /* UI Properties */
    text-align: center;
    font: normal normal bold 36px/44px Calibri;
    letter-spacing: 0px;
    color: rgba(21, 29, 65, 1);
}
</style>