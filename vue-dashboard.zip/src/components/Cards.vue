<template>
    <section class="mt-5">
        <div class="row">
            <p class="text-center latest-api">
                <span>
                    Latest API
                </span>
            </p>
        </div>
        <div class="row d-flex justify-content-between">
            <div class="col-4">
                <div class="card  p-3 mb-5 bg-body-tertiary rounded">
                    <div class="card-body">
                        <h5 class="card-title">26th</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                            the
                            card's content.</p>
                        <h6>Lorem ipsum dolor sit amet,Stet clita</h6>
                        <h5 class="card-title">Know <img src="../assets/arrow.svg"></h5>

                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card  p-3 mb-5 bg-body-tertiary rounded">
                    <div class="card-body">
                        <h5 class="card-title">26th</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                            the
                            card's content.</p>
                        <h6>Lorem ipsum dolor sit amet,Stet clita</h6>
                        <h5 class="card-title">Know <img src="../assets/arrow.svg"></h5>

                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card  p-3 mb-5 bg-body-tertiary rounded">
                    <div class="card-body">
                        <h5 class="card-title">26th</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                            the
                            card's content.</p>
                        <h6>Lorem ipsum dolor sit amet,Stet clita</h6>
                        <h5 class="card-title">Know <img src="../assets/arrow.svg"></h5>

                    </div>
                </div>
            </div>
        </div>

        <div class="row d-flex justify-content-between mt-5">
            <div class="col-4">
                <div class="card  p-3 mb-5 bg-body-tertiary rounded">
                    <div class="card-body">
                        <h5 class="card-title">26th</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                            the
                            card's content.</p>
                        <h6>Lorem ipsum dolor sit amet,Stet clita</h6>
                        <h5 class="card-title">Know <img src="../assets/arrow.svg"></h5>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card  p-3 mb-5 bg-body-tertiary rounded">
                    <div class="card-body">
                        <h5 class="card-title">26th</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                            the
                            card's content.</p>
                        <h6>Lorem ipsum dolor sit amet,Stet clita</h6>
                        <h5 class="card-title">Know <img src="../assets/arrow.svg"></h5>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card  p-3 mb-5 bg-body-tertiary rounded">
                    <div class="card-body">
                        <h5 class="card-title">26th</h5>
                        <p class="card-text">Some quick example text to build on the card title and make up the bulk of
                            the
                            card's content.</p>
                        <h6>Lorem ipsum dolor sit amet,Stet clita</h6>
                        <h5 class="card-title">Know <img src="../assets/arrow.svg"></h5>
                    </div>
                </div>
            </div>

        </div>
    </section>
</template>

<style>
.card {
    width: fit-content;
    height: 227px !important;
    background: #FFFFFF 0% 0% no-repeat padding-box;
    box-shadow: 0px 15px 20px #7682B72D;
    border-radius: 5px;
}

.card-title {
    text-align: left;
    font: normal normal 600 18px/35px Josefin Sans !important;
    letter-spacing: 0px;
    color: #27debf !important;
}

.card-text {
    text-align: left;
    font: normal normal normal 14px/20px Calibri !important;
    letter-spacing: 0px;
    color: #151d41 !important;
}

.card-subtitle {
    text-align: left;
    font: normal normal 600 16px/35px Josefin Sans !important;
    letter-spacing: 0px;
    color: #151d41 !important;
}

.latest-api {
    text-align: left;
    font: normal normal bold 30px/38px Calibri !important;
    letter-spacing: 0px;
    color: #27debf !important;
    text-decoration: underline !important;
    text-decoration-thickness: 5px !important;
}

span {
    color: #151D41;
}
</style>