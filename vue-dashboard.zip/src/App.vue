<script setup>
import Navbar from './components/Navbar.vue'
import Hero from './components/Hero.vue'
//import ProgressCircle from './components/ProgressCircle.vue'
import Cards from './components/Cards.vue'
import Slider from './components/Slider.vue';
</script>

<template>
  <div class="container">
    <Navbar />
    <Hero />
    <!-- <ProgressCircle /> -->
    <Cards />
    <Slider />
  </div>
</template>

<style scoped></style>
